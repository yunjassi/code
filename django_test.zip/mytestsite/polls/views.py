from django.shortcuts import render
from django.http import HttpResponse
from .models import Question
from django.template import loader

List2 = []

def index(request):
    Question1 = Question.objects.all()
    template = loader.get_template('polls/index.html')
    context = {
        'Question1' : Question1,
    }
    return HttpResponse(template.render(context, request))

def complete(request):
    Question1 = Question.objects.all()
    alist1 = Question('list1',False)
    List2.append(alist1)

    return render(request,'polls/index.html',{'List2': List2})




