from django.db import models

class Question(models.Model):
    Question_text = models.CharField(max_length=200)
    Question_List = models.TextField(blank=True)
    def __str__(self):

        return self.Question_text


